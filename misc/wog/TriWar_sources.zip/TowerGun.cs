using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class TowerGun : MonoBehaviour
{
    public SphereCollider Scollider;
    Tower Tower;
    private float attackCD;
    LinkedList<Enemy> EnemyList = new LinkedList<Enemy>();
    RotateAni rotateAni;
    public void Init(Tower tower)
    {
        Scollider = GetComponent<SphereCollider>();
        rotateAni = transform.GetChild(0).GetComponent<RotateAni>();
        Tower = tower;
        attackCD = 0;
        UpdateData();
    }
    public void UpdateData()
    {
        gameObject.SetActive(Tower.Values[1] > 0);
        Scollider.enabled = Tower.Values[1] > 0;
        Scollider.radius = Tower.Values[3] * 0.01f;
        rotateAni.speed = Tower.Values[2] * 6;
        transform.GetChild(0).transform.localScale = Vector3.one * (Mathf.Log10(1+ Tower.Values[1] / 5f));
    }
    // Update is called once per frame
    void Update()
    {
        if(GameManager.instance.Paused) return;
        if (EnemyList.Count > 0)
        {
            if (attackCD <= 0)
            {
                while(EnemyList.Count>0&&(EnemyList.First.Value==null||EnemyList.First.Value.Dead))EnemyList.RemoveFirst();
                if (EnemyList.Count > 0)
                {
                    Attack(EnemyList.First.Value);
                    attackCD = Tower.Values[2] > 0 ? 10f / Tower.Values[2] : 6000;
                }
            }
        }
        if (attackCD > 0)
            attackCD -= Time.deltaTime;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Enemy")
        {
            EnemyList.AddLast(other.gameObject.GetComponent<Enemy>());
        }
    }
    private void OnTriggerExit(Collider other)
    {
        if (other.tag == "Enemy")
        {
            EnemyList.Remove(other.gameObject.GetComponent<Enemy>());
        }
    }

    void Attack(Enemy enemy)
    {
        //transform.eulerAngles=new Vector3(-90,0,Mathf.Atan2(transform.position.z-enemy.transform.position.z,enemy.transform.position.x - transform.position.x)*180f/Mathf.PI);
        Bullet bullet = Instantiate(GameManager.instance.BulletPrefab).GetComponent<Bullet>();
        bullet.Init(transform.position, enemy.transform, 0.3f, Tower.Values[1]);
    }
}
