using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class ValuesUI : MonoBehaviour
{
    Tower Tower;
    Object ValueBlockBase;
    ValueBlockUI ResaultValue;
    List<ValueBlockUI> ValuePositions;
    Transform valueblocks;
    int id = 0;
    Vector3 lastPosition;
    public void Init(Tower tower)
    {
        lastPosition = GameManager.instance.transform.position;
        GameManager.instance.transform.position = transform.position;
        Tower = tower;
        ValueBlockBase = transform.GetChild(0);
        valueblocks = transform.GetChild(1).GetChild(0).GetChild(0);
        //Original Value
        Object v1 = Instantiate(ValueBlockBase, transform);
        v1.GetComponent<RectTransform>().anchoredPosition = new Vector3(17, -30);
        //v1.GetComponent<RectTransform>().sizeDelta = new Vector2(140, -40);
        v1.GetComponent<ValueBlockUI>().Init(-1, -1, this, tower.OriginalValues, new bool[tower.OriginalValues.Length], "ԭʼ", false);
        //Head
        v1 = Instantiate(ValueBlockBase, transform);
        v1.GetComponent<ValueBlockUI>().Init(-1, -1, this, tower.OriginalValues, new bool[tower.OriginalValues.Length], "����", false);
        v1.GetComponent<RectTransform>().anchoredPosition = new Vector3(7, -30);
        //v1.GetComponent<RectTransform>().sizeDelta = new Vector2(140, -40); 
        v1.GetComponent<ValueBlockUI>().SetText(new string[] { "����", "�˺�","�ٶ�","��Χ","����"});
        //Resault
        v1 = Instantiate(ValueBlockBase, transform);
        RectTransform rect = v1.GetComponent<RectTransform>();
        rect.anchoredPosition = new Vector3(93, -30);
        //rect.sizeDelta = new Vector2(140, -40);
        ResaultValue = v1.GetComponent<ValueBlockUI>();
        ResaultValue.Init(-2, -1, this, tower.Values, new bool[tower.OriginalValues.Length], "����", false);
        //Values
        ValuePositions = new List<ValueBlockUI>();
        foreach (int i in tower.NowIds)
        {
            AddBlock(i);
        }
        //Buttons
        transform.GetChild(2).GetComponent<Button>().onClick.AddListener(Close);
        transform.GetChild(3).GetComponent<Button>().onClick.AddListener(Up);
        UpdataCost();
        gameObject.SetActive(true);
        GameManager.instance.InputPaused = true;
        Time.timeScale = 0.1f;
    }

    private void AddBlock(int i)
    {
        Object v = Instantiate(ValueBlockBase, valueblocks);
        ValuePositions.Add(v.GetComponent<ValueBlockUI>());
        ValuePositions[id].Init(id, i, this, Tower.Enhancements[i].ValuesEnhance, Tower.Enhancements[i].IsMultiply, "#" + i.ToString(), true);
        id++;
        v.GetComponent<RectTransform>().anchoredPosition = new Vector3(-5 + 10 * id, -28);
        valueblocks.GetComponent<RectTransform>().sizeDelta = new Vector2(Mathf.Max(64, id * 10), 58);
    }

    private void UpdataCost()
    {
        transform.GetChild(3).GetChild(0).GetComponent<TextMeshProUGUI>().text = string.Format("{0:f1}", Tower.NextLevelCost);
    }

    public void Move(ValueBlockUI ui, int dir)
    {
        int toi = ui.ID + dir, uid=ui.ID;
        if (toi < 0 || toi > ValuePositions.Count - 1) return;
        (ValuePositions[toi].GetComponent<RectTransform>().anchoredPosition, ui.GetComponent<RectTransform>().anchoredPosition) = (ui.GetComponent<RectTransform>().anchoredPosition, ValuePositions[toi].GetComponent<RectTransform>().anchoredPosition);
        (ValuePositions[toi].ID, ValuePositions[uid].ID) = (ValuePositions[uid].ID, ValuePositions[toi].ID);
        (ValuePositions[toi], ValuePositions[uid]) = (ValuePositions[uid], ValuePositions[toi]);
        UpdateResault();
    }

    private void UpdateResault()
    {
        float[] v = (float[])Tower.OriginalValues.Clone();
        int[] ids = new int[ValuePositions.Count];
        for (int i = 0; i < ValuePositions.Count; i++)
        {
            v = Tower.Enhancements[ValuePositions[i].VID].Apply(v);
            ids[i] = ValuePositions[i].VID;
        }
        Tower.ApplyAll(ids);
        ResaultValue.SetText(v, new bool[v.Length]);
    }

    public void Close()
    {
        GameManager.instance.transform.position = lastPosition;
        gameObject.SetActive(false);
        Time.timeScale = 1f;
        Destroy(gameObject, 0.1f);
    }
    public void Up()
    {
        if (Tower.LevelUp())
        {
            AddBlock(id);
            UpdateResault();
            UpdataCost();
        }
    }
    private void OnDestroy()
    {
        Time.timeScale = 1f;
        GameManager.instance.InputPaused = false;
    }
}
