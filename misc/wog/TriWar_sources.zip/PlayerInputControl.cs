using Cinemachine;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerInputControl : MonoBehaviour
{
    public float speed = 5;
    public float zoomf = 1;
    public static PlayerInputControl instance;
    public Transform Controller;
    float TouchOri;
    Vector3 moveOri;
    Vector3 lastpos;
    bool onZoom = false;
    private void Awake()
    {
        instance = this;
    }
    Vector3 GetTouchPosition(Vector3 mouse) => Camera.main.ScreenToWorldPoint(new Vector3(mouse.x, mouse.y, Camera.main.transform.position.y+0.5f));
    // Update is called once per frame
    void Update()
    {
        if (GameManager.instance.InputPaused) return;
        if (Input.GetKey(KeyCode.Escape))
        {
            GameManager.instance.ShowSettings();
            return;
        }
        float x = Input.GetAxis("Horizontal");
        float y = Input.GetAxis("Vertical");
        float n = Input.GetAxis("Mouse ScrollWheel");
        Vector3 newpos = transform.position + new Vector3(x * Time.deltaTime * speed, -n * zoomf, y * Time.deltaTime * speed);
        if (Input.touchCount == 0)
        {
            if (Input.GetMouseButtonDown(0))
            {
                lastpos = GetTouchPosition(Input.mousePosition);
                moveOri = transform.position;
            }
            else if (Input.GetMouseButton(0))
            {
                Vector3 v = GetTouchPosition(Input.mousePosition);
                newpos += GameManager.Constrains(lastpos-v);
                lastpos = v;
            }
            else if (Input.GetMouseButtonUp(0))
            {
                if ((transform.position - moveOri).magnitude <= 0.1f)
                {
                    CancelInvoke(nameof(HideController));
                    Controller.position = GameManager.Constrains(GetTouchPosition(Input.mousePosition));
                    Controller.gameObject.SetActive(true);
                    float time = GameManager.instance.Player.GoTo(Controller.position);
                    Invoke(nameof(HideController), time);
                }
            }
            onZoom = false;
        }
        else
        {
            if (Input.touchCount == 1&&!onZoom)
            {
                Touch touch = Input.GetTouch(0);
                if (touch.phase == TouchPhase.Began)
                {
                    lastpos = GetTouchPosition(touch.position);
                    moveOri = transform.position;
                }
                else if (touch.phase == TouchPhase.Moved)
                {
                    Vector3 v = GetTouchPosition(touch.position);
                    newpos += GameManager.Constrains(lastpos - v);
                    lastpos = v;
                }
                else if(touch.phase==TouchPhase.Ended)
                    if ((transform.position - moveOri).magnitude <= 0.1f)
                    {
                        CancelInvoke(nameof(HideController));
                        Controller.position = GameManager.Constrains(GetTouchPosition(Input.mousePosition));
                        Controller.gameObject.SetActive(true);
                        float time = GameManager.instance.Player.GoTo(Controller.position);
                        Invoke(nameof(HideController), time);
                    }
            }
            else if (Input.touchCount == 2)
            {
                Touch touch1 = Input.GetTouch(0), touch2=Input.GetTouch(1);
                if(!onZoom)
                {
                    TouchOri = (GetTouchPosition(touch1.position) - GetTouchPosition(touch2.position)).magnitude;
                    onZoom = true;
                }
                else
                {
                    float delta = (GetTouchPosition(touch1.position) - GetTouchPosition(touch2.position)).magnitude;
                    newpos.y = (newpos.y + 10.5f) * TouchOri / delta-10.5f;
                }
            }
            else
                onZoom = false;
        }
        transform.position = new Vector3( newpos.x,Mathf.Max(newpos.y,-8),newpos.z);
    }

    void HideController()
    {
        Controller.gameObject.SetActive(false);
    }
}
