using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using TMPro;
using Unity.VisualScripting;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;

public class ObjectCanvas : MonoBehaviour
{
    Image OccImage;
    TextMeshProUGUI OccText;
    Image HealImage;
    Tower Tower;

    public void Init(Tower tower)
    {
        Tower = tower;
        OccImage = transform.GetChild(0).GetComponent<Image>();
        OccText = transform.GetChild(1).GetComponent<TextMeshProUGUI>();
        HealImage = transform.GetChild(2).GetComponent<Image>();
        OccImage.fillAmount = 0;
        HealImage.fillAmount = 1;
        transform.GetChild(3).GetComponent<Button>().onClick.AddListener(() =>
        {
            ValuesUI valuesUI = Instantiate(GameManager.instance.ValuePannel, transform).GetComponent<ValuesUI>();
            valuesUI.Init(tower);
        });
        GetComponent<Canvas>().worldCamera = Camera.main;
        SetProcessVisible(false);
        SetHealthVisible(false);
        SetEditButtonVisible(false);
        SetTextVisible(false);
        gameObject.SetActive(true);
    }

    public void SetProcess(float process)
    {
        OccImage.fillAmount = process;
        OccText.text = string.Format("<#f15f00>{0:f1}</color>", process * 100);
    }

    public void SetProcessVisible(bool visible)
    {
        transform.GetChild(0).gameObject.SetActive(visible);
    }
    public void SetHealth(float nowhealth, float maxhealth)
    {
        HealImage.fillAmount = nowhealth/maxhealth;
        OccText.text = string.Format("<#4cfd28>{0:f1}</color>", nowhealth);
    }
    public void SetHealthVisible(bool visible)
    {
        transform.GetChild(2).gameObject.SetActive(visible);
    }
    public void SetTextVisible(bool visible)
    {
        transform.GetChild(1).gameObject.SetActive(visible);
    }
    public void SetEditButtonVisible(bool visible)
    {
        transform.GetChild(3).gameObject.SetActive(visible);
    }
}
