using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.PlayerLoop;
using Object = UnityEngine.Object;
using Random = UnityEngine.Random;

public class MapManager : MonoBehaviour
{
    public Dictionary<Point, Tower> Map;
    public static Point[] Directions = new Point[] { new Point(0, 1), new Point(1, 1), new Point(1, 0), new Point(1, -1), new Point(-1, 1), new Point(-1, 0), new Point(-1, -1), new Point(0, -1) };
    public int Distence = 0;
    public float BlockSize = 6f;
    public int TowerCount;
    private HashSet<Point> GeneratedPoints;
    public Dictionary<int, Point> IdToBlock;

    public void StartGame()
    {
        for (int i = 0; i < transform.childCount; i++)
        {
            Destroy(transform.GetChild(i).gameObject);
        }
        //Debug.Log(transform.childCount);
        TowerCount = 0;
        Map = new Dictionary<Point, Tower>();
        IdToBlock = new Dictionary<int, Point>();
        GeneratedPoints = new HashSet<Point>();
        BuildTower(6, new float[] { 10, 30, 10f, 5f, 1000f }, 1, new Point(0, 0)).Occipied();
    }
    private Tower GenerateBlock(Point block)
    {
        Tower tower = Instantiate(GameManager.instance.TowerPrefab, transform).GetComponent<Tower>();
        tower.Init(TowerCount++);
        ItemsBlock itemsBlock=null;
        if(Random.Range(0,2) == 0)
        {
            itemsBlock=Instantiate(GameManager.instance.ItemBlockPrefab, transform).GetComponent<ItemsBlock>();
            itemsBlock.InitRandom();
        }
        SetBlock(block, tower, itemsBlock);
        return tower;
    }
    private void SetBlock(Point block, Tower tower, ItemsBlock itemsBlock=null)
    {
        if(itemsBlock != null)
        {
            itemsBlock.transform.position = new Vector3(block.X * BlockSize + Random.Range(-BlockSize / 2f + 2, BlockSize / 2f - 2), 0, block.Y * BlockSize + Random.Range(-BlockSize / 2f + 2, BlockSize / 2f - 2));
        }
        tower.gameObject.transform.position = new Vector3(block.X * BlockSize + Random.Range(-BlockSize / 2f + 2, BlockSize / 2f - 2), 0, block.Y * BlockSize + Random.Range(-BlockSize / 2f + 2, BlockSize / 2f - 2));
        if (Map.TryGetValue(block, out Tower t1))
        {
            for(int i = 0; i < 8; i++)
            {
                if (t1.Around[i] != null)
                    t1.Around[7 - i] = tower;
            }
            Destroy(t1.gameObject);
        }
        else
        {
            Transform floor = Instantiate(GameManager.instance.FloorPrefab, transform).GetComponent<Transform>();
            floor.position = new Vector3(block.X * BlockSize, -0.5f, block.Y * BlockSize);
            floor.localScale = new Vector3(BlockSize / 10f, 1, BlockSize / 10f);
            floor.gameObject.SetActive(true);
        }
        Map[block] = tower;
        IdToBlock[tower.ID] = block;
        for (int i = 0; i < 8; i++)
        {
            Point point = new(block.X + Directions[i].X, block.Y + Directions[i].Y);
            if (Map.ContainsKey(point))
            {
                tower.Around[i] = Map[point];
                Map[point].Around[7 - i] = tower;
            }
        }
    }
    public void GenerateMap(Point point, int distence)
    {
        for (int x = point.X - distence; x <= point.X + distence; x++) 
            for(int y = point.Y - distence; y <= point.Y + distence; y++)
            {
                Point p = new Point(x, y);
                if(!Map.ContainsKey(p))
                    GenerateBlock(p);
            }
    }

    public Tower BuildTower(int level, float[] values, float occupytime, Point block)
    {
        Tower tower = Instantiate(GameManager.instance.TowerPrefab, transform).GetComponent<Tower>();
        tower.Init(values, level, TowerCount++, occupytime);
        SetBlock(block, tower);
        return tower;
    }

    public Point PositionToBlock(Vector3 position) => new Point(Mathf.RoundToInt(position.x / BlockSize), Mathf.RoundToInt(position.z / BlockSize));

    private void Update()
    {
        if (GameManager.instance.Paused) return;
        Point p = PositionToBlock(GameManager.instance.Player.transform.position);
        if (!GeneratedPoints.Contains(p))
        {
            GeneratedPoints.Add(p);
            GenerateMap(p, Distence);
        }
    }
    public Tower GetNearestTower(Vector3 position, bool occupied)
    {
        Point p=PositionToBlock(position);
        Queue<Tower> towers = new Queue<Tower>();
        HashSet<int> visited = new HashSet<int>();
        towers.Enqueue(Map[p]);
        while (towers.Count > 0)
        {
            Tower tower = towers.Dequeue();
            visited.Add(tower.ID);
            if(tower.Occupied==occupied)
                return tower;
            for(int i=0;i<8;i++)
                if (tower.Around[i] != null &&!visited.Contains( tower.Around[i].ID))
                    towers.Enqueue(tower.Around[i]);
        }
        return null;
    }

    public RectangleF GetBlockRect(Point point)=>new RectangleF(point.X*BlockSize-BlockSize/2f, point.Y*BlockSize-BlockSize/2f,BlockSize,BlockSize);

    public List<Tower> GetAllAroundTowers(Tower tower2, bool occupied)
    {
        List<Tower> re=new List<Tower>();
        Queue<Tower> towers = new Queue<Tower>();
        HashSet<int> visited = new HashSet<int>();
        towers.Enqueue(tower2);
        while (towers.Count > 0)
        {
            Tower tower = towers.Dequeue();
            visited.Add(tower.ID);
            if (tower.Occupied == occupied)
                re.Add(tower);
            else
            {
                for (int i = 0; i < 8; i++)
                    if (tower.Around[i] != null && !visited.Contains(tower.Around[i].ID))
                        towers.Enqueue(tower.Around[i]);
            }
        }
        return re;
    }

    public static Point[] GetPointsInRange(int x, int y, int range) //max(|x-x1|,|y-y1|)=range
    {
        Point[] re=new Point[range*8];//(2r+1)^2-(2r-1)^2=8r
        int i = 0;
        for(int x1 = x - range; x1 <= x + range; x1++)
        {
            re[i++] = new Point(x1, y + range);
            re[i++] = new Point(x1, y - range);
        }
        for (int y1 = y - range+1; y1 < y + range; y1++)
        {
            re[i++] = new Point(x+range, y1 + range);
            re[i++] = new Point(x+range, y1 - range);
        }
        return re;
    }
}
