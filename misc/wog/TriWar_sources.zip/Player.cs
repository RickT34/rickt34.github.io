using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Player : MonoBehaviour
{
    // Start is called before the first frame update
    Rigidbody rb;
    public float Speed;
    private Vector3 to;
    public float TowerCureSpeed;
    public float TowerOccupySpeed;
    public int level;
    ParticleSystem upingEff;
    public void StartGame()
    {
        rb = GetComponent<Rigidbody>();
        GameManager.instance.Player = this;
        TowerCureSpeed = 1.5f;
        TowerOccupySpeed = 1f;
        transform.position = Vector3.zero;
        level = 1;
        Speed = 1f;
        Stop();
        CancelInvoke();
        StopUpingEff();
    }
    public float GoTo(Vector3 position)
    {
        CancelInvoke(nameof(Stop));
        to = position - transform.position;
        to.y = 0;
        float time = to.magnitude / Speed;
        rb.velocity = to.normalized * Speed;
        rb.transform.LookAt(GameManager.Constrains(position));
        Invoke(nameof(Stop), time);
        return time;
    }

    public void UpGrade()
    {
        level++;
        TowerCureSpeed += 0.5f;
        TowerOccupySpeed *= 1.5f;
        Speed = Mathf.Sqrt(level);
        StopUpingEff();
        upingEff =Instantiate(GameManager.instance.LevelUpEffPrefab,transform).GetComponent<ParticleSystem>();
        Invoke(nameof(StopUpingEff), 1f);
        GameManager.instance.UpdateTexts();
    }
    void StopUpingEff()
    {
        if (upingEff != null)
        {
            upingEff.Stop();
            Destroy(upingEff.gameObject, 2f);
            upingEff=null;
        }
    }

void Stop()
    {
        rb.velocity = Vector3.zero;
    }
}
