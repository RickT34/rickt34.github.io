using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;
using System.Drawing;
using UnityEngine.TextCore.Text;
using Debug = UnityEngine.Debug;

public class GameManager : MonoBehaviour
{
    // Start is called before the first frame update
    public List<Tower> OccupiedTowers;
    public HashSet<Enemy> Enemies;
    public float EdgeCoins;
    public Object CycCanvas;
    public Object TowerPrefab;
    public Object FloorPrefab;
    public Object EnemyPrefab;
    public Object ItemBlockPrefab;
    public Object SettingPanelPrefab;
    public Object LevelUpEffPrefab;
    public Object HealingEffPrefab;
    public Object HittedEffPrefab;
    public Object OccupyingEffPrefab;
    public Object PickEffPrefab;
    public Object EnemyDiedPrefab;
    public Object TowerDiedPrefab;
    public Player Player;
    public Mesh[] TowerMeshes;
    public Mesh[] EnemyMeshes;
    public MapManager mapManager;
    public Object BulletPrefab;
    public TextMeshProUGUI CoinText;
    public TextMeshProUGUI LeftTimeText;
    public TextMeshProUGUI LevelText;
    public TextMeshProUGUI GameOverText;
    public TextMeshProUGUI MsgText;
    public TextMeshProUGUI ExpText;
    public Button SettingB;
    public Button HomeB;
    public Object ValuePannel;
    public Canvas Canvas;
    public Object RangeIndicatorPrefab;
    public static string[] LeftColors;
    public TMP_FontAsset NumberFont;
    public TMP_FontAsset WordFont;
    private bool paused;
    private bool inputPaused;
    public int GameLevel;
    public float leftSect;
    float leftScetOri;
    float inComeps;
    int playerExp;
    int playerExpnxt;
    void Start()
    {
        instance = this;
        LeftColors = new string[512];
        for (int i = 0; i < 256; i++)
        {
            LeftColors[i] = string.Format("{0:X2}FF00", i);
            LeftColors[i + 256] = string.Format("FF{0:X2}00", 255 - i);
        }
        SettingB.onClick.AddListener(ShowSettings);
        HomeB.onClick.AddListener(GoHome);
        GameOverText.transform.GetChild(0).GetComponent<Button>().onClick.AddListener(StartGame);
        StartGame();
    }
    void GoHome()
    {
        PlayerInputControl.instance.transform.position = Player.transform.position;
    }
    private void Update()
    {
        if (!Paused)
        {
            EdgeCoins = Mathf.Max(0, EdgeCoins + inComeps * Time.deltaTime);
            CoinText.text = string.Format("Coins: <size=+18>{0:f1}</size> <i>+{1:f1}/s</i>", EdgeCoins, inComeps); CoinText.text = string.Format("Coins: <size=+18>{0:f1}</size> <i>" + (inComeps >= 0 ? "+" : "") + "{1:f1}/s</i>", EdgeCoins, inComeps);
            leftSect-=Time.deltaTime;
            LeftTimeText.text = "Next wave: <size=+10><#" + LeftColors[Mathf.Clamp((int)(512*(leftScetOri - leftSect) / leftScetOri), 0, 511)] + ">" + string.Format("{0:f1}",leftSect) + "</color></size>";
            if (leftSect <= 0)
                NextWave();
        }
    }
    public void UpdateIncome()
    {
        inComeps = 0f;
        foreach (Tower tower in OccupiedTowers)
        {
            inComeps += tower.Values[0];
        }
        inComeps = Mathf.Max(1, inComeps);
    }
    public bool SpendCoins(float amount)
    {
        if(amount>EdgeCoins)
            return false;
        EdgeCoins -=amount;
        return true;
    }

    public void AddTower(Tower tower)
    {
        OccupiedTowers.Add(tower);
        UpdateIncome();
    }

    public void RemoveTower(Tower tower)
    {
        OccupiedTowers.Remove(tower);
        UpdateIncome();
        if (OccupiedTowers.Count == 0)
            GameOver();
    }
    public void AddExp()
    {
        playerExp += 1;
        if(playerExp >= playerExpnxt)
        {
            Player.UpGrade();
            playerExp = 0;
            if(Player.level>=12) playerExpnxt <<=2;
            else playerExpnxt <<=1;
        }
        UpdateTexts();
    }
    public static GameManager instance;

    public void ShowMessage(string message)
    {
        CancelInvoke(nameof(ClearMessage));
        MsgText.text = message;
        Invoke(nameof(ClearMessage), 3f);
    }

    public void ClearMessage()
    {
        MsgText.text = "";
    }

    public bool Paused { get => paused; set
        {
            paused = value;
            InputPaused = paused;
            Time.timeScale = paused ? 0 : 1;
            //Debug.Log(paused);
        }
    }

    public bool InputPaused { get => inputPaused; set
        {
            SettingB.gameObject.SetActive(!value);
            HomeB.gameObject.SetActive(!value);
            SettingB.GetComponent<Image>().raycastTarget = !value;
            HomeB.GetComponent<Image>().raycastTarget = !value;
            inputPaused = value;
        }
    }

    public static Vector3 Constrains(Vector3 vector, float y = 0) => new Vector3(vector.x, y, vector.z);

    public void StartGame()
    {
        GameOverText.gameObject.SetActive(false);
        leftSect = 20;
        GameLevel = 1;
        leftScetOri = leftSect;
        EdgeCoins = 0;
        playerExp = 0;
        playerExpnxt = 1;
        EdgeCoins = 0;
        inComeps = 0;
        OccupiedTowers = new List<Tower>();
        if (Enemies != null)
            foreach (Enemy enemy in Enemies)
                Destroy(enemy.gameObject);
        Enemies = new HashSet<Enemy>();
        transform.position = Vector3.zero;
        Player.StartGame();
        mapManager.StartGame();
        UpdateTexts();
        ShowSettings();
    }

    public void UpdateTexts()
    {
        LevelText.text = "Level " + GameLevel.ToString();
        ExpText.text = "EXP: " + playerExp.ToString() + " / " + playerExpnxt.ToString() + "\nLV: " + Player.level.ToString();
    }

    public void NextWave()
    {
        leftScetOri = 10;
        leftSect = 10;
        int amout = (int)Mathf.Sqrt(GameLevel*2);
        bool hasAir = GameLevel > 4;
        Tower t = OccupiedTowers[Random.Range(0, OccupiedTowers.Count)];
        List<Tower> spawns = mapManager.GetAllAroundTowers(t, false);
        while (amout > 0)
        {
            int rank = Random.Range(0, 4) == 0 ? 1 : 0;
            if (GameLevel < 3) rank = 0;
            if (hasAir) rank += Random.Range(0, 4) == 0 ? 2 : 0;
            SpawnEnemy(spawns[Random.Range(0, spawns.Count)], rank, GameLevel);
            amout--;
        }
        GameLevel++;
        UpdateTexts();
    }

    public void SpawnEnemy(Tower t, int rank, int level)
    {
        RectangleF rect = mapManager.GetBlockRect(mapManager.IdToBlock[t.ID]);
        Enemy enemy = Instantiate(EnemyPrefab).GetComponent<Enemy>();
        Enemies.Add(enemy);
        enemy.transform.position = new Vector3(rect.X + Random.Range(0, rect.Width), 0, rect.Y + Random.Range(0, rect.Height));
        enemy.Init(rank, level);
    }
    public void GameOver()
    {
        Paused=true;
        GameOverText.text = "Game Over\n<size=-150>level " + GameLevel.ToString() + "</size>";
        GameOverText.gameObject.SetActive(true);
    }
    public void ShowSettings()
    {
        Instantiate(SettingPanelPrefab, Canvas.transform).GetComponent<SettingsPanel>().Init();
    }
}
