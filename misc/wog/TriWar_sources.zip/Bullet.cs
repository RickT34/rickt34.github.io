using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class Bullet : MonoBehaviour
{
    public float Speed;
    Rigidbody rb;
    Transform target;
    float colRange;
    float damage;
    void Awake()
    {
        rb= GetComponent<Rigidbody>();
    }
    public void Init(Vector3 position,Transform target, float ColRange, float damage)
    {
        this.target = target;
        colRange = ColRange;
        this.damage = damage;
        transform.position = position;
        transform.LookAt(position);
        gameObject.SetActive(true);
    }
    private void FixedUpdate()
    {
        if (target == null)
        {
            gameObject.SetActive(false);
            Destroy(gameObject); return;
        }
        Vector3 delta = target.position - transform.position;
        if (delta.magnitude <= colRange)
        {
            if (target.gameObject.tag == "Tower")
                target.GetComponent<Tower>().Hitted(damage);
            else if(target.gameObject.tag =="Enemy")
                target.GetComponent<Enemy>().Hitted(damage);
            gameObject.SetActive(false);
            Destroy(gameObject); return;
        }
        transform.LookAt(target.position);
        rb.velocity = delta.normalized*Speed;
    }
}
