using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SettingsPanel : MonoBehaviour
{
    public void Init()
    {
        transform.GetChild(0).GetComponent<Button>().onClick.AddListener(Close);
        gameObject.SetActive(true);
        GameManager.instance.Paused = true;
    }
    void Close()
    {
        gameObject.SetActive(false);
        GameManager.instance.Paused = false;
        GameManager.instance.InputPaused = true;
        Destroy(gameObject,0.1f);
    }
    private void OnDestroy()
    {
        GameManager.instance.InputPaused = false;
    }
}
