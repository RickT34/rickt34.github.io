using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using Unity.VisualScripting;
using UnityEngine;
using Color = UnityEngine.Color;

public class ItemsBlock : MonoBehaviour
{
    public int Type;
    public void Init(int type)//0:coins 1:addtime 2:playerUpgrade 3:towerUpgrade 4:heal 5:enemy 6:nextwave
    {
        Type = type;
        Color color = new Color(Random.Range(0.5f, 1f), Random.Range(0.5f, 1f), Random.Range(0.5f, 1f), Random.Range(0.5f, 0.8f));
        Material material = new Material(transform.GetComponent<MeshRenderer>().material);
        material.color = color;
        transform.GetComponent<MeshRenderer>().material=material;
        transform.GetChild(0).GetComponent<Light>().color = color;
        gameObject.SetActive(true);
    }
    public void InitRandom()
    {
        Init(Random.Range(0, 7));
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
        {
            float add;
            switch (Type)
            {
                case 0:
                    add = Random.Range(50f, 500f)*GameManager.instance.GameLevel;
                    GameManager.instance.EdgeCoins += add;
                    GameManager.instance.ShowMessage(string.Format("���� {0:f1}", add));
                    break;
                case 1:
                    add = Random.Range(1f, 20f);
                    GameManager.instance.leftSect += add;
                    GameManager.instance.ShowMessage("�ӳ� " + string.Format("{0:f1}",add) + "s");
                    break;
                case 2:
                    GameManager.instance.Player.UpGrade();
                    GameManager.instance.ShowMessage("�������");
                    break;
                case 3:
                    Tower tower = GameManager.instance.mapManager.GetNearestTower(transform.position, true);
                    tower.LevelUp(true);
                    GameManager.instance.ShowMessage("������");
                    break;
                case 4:
                    foreach(Tower tower1 in GameManager.instance.OccupiedTowers)
                    {
                        tower1.Health += 1000f;
                    }
                    GameManager.instance.ShowMessage("������");
                    break;
                case 5:
                    GameManager.instance.SpawnEnemy(GameManager.instance.mapManager.GetNearestTower(transform.position, true), Random.Range(0, 4), GameManager.instance.GameLevel + 2);
                    GameManager.instance.ShowMessage("����!");
                    break;
                case 6:
                    add = Random.Range(1f, 20f);
                    GameManager.instance.leftSect -= add;
                    GameManager.instance.ShowMessage("���� " + string.Format("{0:f1}", add) + "s");
                    break;
            }
            hittedEff = Instantiate(GameManager.instance.PickEffPrefab).GetComponent<ParticleSystem>();
            hittedEff.transform.position = transform.position;
            Invoke(nameof(StopHitEff), 2f);
            gameObject.SetActive(false);
            Destroy(gameObject, 3f);
        }
    }
    ParticleSystem hittedEff;
    void StopHitEff()
    {
        hittedEff.Stop();
        Destroy(hittedEff.gameObject, 2f);
        hittedEff= null;
    }
    private void OnDestroy()
    {
        if (hittedEff != null)
            StopHitEff();
    }
}
