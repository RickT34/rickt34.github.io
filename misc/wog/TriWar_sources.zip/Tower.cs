using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;
using Object = UnityEngine.Object;
using Random = UnityEngine.Random;

public class Tower : MonoBehaviour
{
    // 0CoinsIncome = 0f; 1AttackPower = 0f; 2AttackSpeed = 1f; 3AttackRange = 5f; 4HealthMax = 100f;
    public float[] OriginalValues = new float[] {0f,0f,1f,5f,0f };
    public float[] Values;
    public const int ValuesCount = 5;
    public bool Occupied;
    public Tower[] Around;
    public float ColRange = 1f;
    public float Health { get => health;
        set
        {
            if (value <= 0)
            {
                UnOccupied();
            }
            else
            {
                health = Mathf.Min( value, Values[4]);
            }
            Cyccanvas.SetHealthVisible(Occupied && (health / Values[4] < 0.99f));
            Cyccanvas.SetHealth(value , Values[4]);
        }
    }
    private float health;
    private float healRate=1f;
    public List<Enhancement> Enhancements;
    public List<int> NowIds;
    public float NextLevelCost;
    private float OccupyTime;
    private float OccupyProcess=0;
    public int level;
    private ObjectCanvas Cyccanvas
    {
        get
        {
            if (cyccanvas == null)
            {
                cyccanvas = Instantiate(GameManager.instance.CycCanvas, transform).GetComponent<ObjectCanvas>();
                cyccanvas.Init(this);
            }
            return cyccanvas;
        }
    }
    private ObjectCanvas cyccanvas;
    private ParticleSystem healingEff;
    private ParticleSystem upingEff;
    private ParticleSystem rangeEff;
    bool Occupying;
    private bool Healing;
    private int MaxLevel;
    private Color color;
    private Light towerLight;
    private TowerGun towerGun;
    public int ID;

    public void Init(float[] ValueSet, int maxLevel, int id, float occupyTime)
    {
        ID = id;
        Enhancements = new List<Enhancement>();
        OriginalValues = (float[])ValueSet.Clone();
        NowIds = new List<int>();
        Around = new Tower[8];
        health = OriginalValues[4];
        level = 0;
        Values = (float[])OriginalValues.Clone();
        Occupied = false;
        NextLevelCost = Random.Range(15f, 18f);
        Occupying = false;
        Healing = false;
        MaxLevel = maxLevel;
        OccupyTime = occupyTime;
        transform.GetComponent<MeshFilter>().mesh = GameManager.instance.TowerMeshes[maxLevel - 3];
        color = new Color(Random.Range(0.5f, 1f), Random.Range(0.5f, 1f), Random.Range(0.5f, 1f), Random.Range(0.5f, 0.8f));
        Material material = new Material(transform.GetComponent<MeshRenderer>().material);
        material.color = color;
        transform.GetComponent<MeshRenderer>().material = material;
        towerLight = transform.GetChild(1).GetComponent<Light>();
        towerLight.gameObject.SetActive(false);
        color.a = 1;
        towerLight.color = color;
        towerGun = transform.GetChild(0).GetComponent<TowerGun>();
        towerGun.transform.GetChild(0).GetComponent<MeshRenderer>().material = material;
        ParticleSystem.MainModule mmo = towerGun.transform.GetChild(0).GetChild(0).GetComponent<ParticleSystem>().main;
        mmo.startColor = new ParticleSystem.MinMaxGradient(color, Color.yellow);
        towerGun.Init(this);
        towerGun.gameObject.SetActive(false);
        SetLight();
        gameObject.SetActive(true);
    }

    public void Init(int id)
    {
        int level = Random.Range(3, 9);
        float CoinsIncome = level > 4 ? Random.Range(10f, 20f) : 0f,
            AttackPower = Random.Range(0, 2) == 0 ? Random.Range(10f, 30f) : 0f,
            AttackSpeed = Random.Range(5f, 15f),
            AttackRange = Random.Range(4f, 6f),
            HealthMax = 300 + Random.Range(80f, 120f) * level;

        //Init((float)(Random.Range(80f, 120f) * Math.Pow(1.3, level - 3)), level, id, 2 << (level - 2))
        Init(new float[] { CoinsIncome, AttackPower, AttackSpeed, AttackRange, HealthMax }, level, id, 4 << (level-2));
    }
    // Update is called once per frame
    void Update()
    {
        if (GameManager.instance.Paused) return;
        if (Occupying)
        {
            Cyccanvas.SetProcess(OccupyProcess / OccupyTime);
            if (OccupyProcess >= OccupyTime)
            {
                Occipied();
                Occupying = false;
                OccupyProcess = 0;
                PlayerEnter();
                occpyingEff.Stop();
                Destroy(occpyingEff.gameObject, 2f);
                occpyingEff = null;
            }
            OccupyProcess += Time.deltaTime*GameManager.instance.Player.TowerOccupySpeed;
        }
        else
        {
            if (Occupied)
            {
                Health = Mathf.Min(Health + healRate * Time.deltaTime * (Healing ? GameManager.instance.Player.TowerCureSpeed : 1f), Values[4]);
            }
            else
            {
                if (OccupyProcess > 0)
                {
                    OccupyProcess -= Time.deltaTime;
                    Cyccanvas.SetProcess(OccupyProcess / OccupyTime);
                    if (OccupyProcess <= 0)
                    {
                        OccupyProcess = 0;
                        Cyccanvas.SetProcessVisible(false);
                        Cyccanvas.SetTextVisible(false);
                    }
                }
            }
        }
        
    }

    private void SetLight()
    {
        towerLight.range = Values[3] * 2;
        towerLight.intensity = level * 0.2f + 1.5f;
    }

    public void Occipied()
    {
        Occupied = true;
        GameManager.instance.AddTower(this);
        Cyccanvas.SetProcessVisible(false);
        Cyccanvas.SetHealthVisible(true);
        towerGun.gameObject.SetActive(true);
        Health = health;
        towerLight.gameObject.SetActive(true);
    }
    ParticleSystem diedEff;
    private void UnOccupied()
    {
        Occupied = false;
        health = 1f;
        diedEff = Instantiate(GameManager.instance.TowerDiedPrefab).GetComponent<ParticleSystem>();
        diedEff.transform.position = transform.position;
        Invoke(nameof(HideDiedEff), 0.5f);
        GameManager.instance.RemoveTower(this);
        Destroy(cyccanvas.gameObject);
        towerGun.gameObject.SetActive(false);
        towerLight.gameObject.SetActive(false);
        PlayerLeave();
    }
    void HideDiedEff()
    {
        if (diedEff == null) return;
        diedEff.Stop();
        Destroy(diedEff.gameObject, 0.5f);
        diedEff = null;
    }
    ParticleSystem occpyingEff;
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
        {
            Cyccanvas.SetTextVisible(true);
            if (!Occupied)
            {
                Occupying = true;
                Cyccanvas.SetProcessVisible(true);
                Cyccanvas.SetProcess(0);
                occpyingEff=Instantiate(GameManager.instance.OccupyingEffPrefab).GetComponent<ParticleSystem>();
                occpyingEff.transform.position = transform.position;
            }
            else
            {
                PlayerEnter();
            }
        }
    }

    private void PlayerEnter()
    {
        ShowEdit();
        Healing = true;
        healingEff = Instantiate(GameManager.instance.HealingEffPrefab).GetComponent<ParticleSystem>();
        healingEff.transform.position = transform.position;
    }

    private void ShowEdit()
    {
        cyccanvas.SetEditButtonVisible(true);
        rangeEff = Instantiate(GameManager.instance.RangeIndicatorPrefab).GetComponent<ParticleSystem>();
        rangeEff.transform.position = transform.position;
        rangeEff.transform.localScale *= towerGun.Scollider.radius * 100f;
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.tag == "Player")
        {
            if (!Occupied)
            {
                Occupying = false;
                if(occpyingEff != null)
                {
                    occpyingEff.Stop();
                    Destroy(occpyingEff.gameObject, 2f);
                }
            }
            PlayerLeave();
        }
    }

    private void PlayerLeave()
    {
        HideEdit();
        Cyccanvas.SetTextVisible(false);
        Healing = false;
        if(healingEff != null)
        {
            healingEff.Stop();
            Destroy(healingEff.gameObject, 2f);
        }
    }

    private void HideEdit()
    {
        if(cyccanvas != null)
            cyccanvas.SetEditButtonVisible(false);
        if(rangeEff != null)
        {
            rangeEff.Stop();
            Destroy(rangeEff.gameObject, 2f);
            rangeEff = null;
        }
    }
    ParticleSystem hittedEff;
    public void Hitted(float power)
    {
        if (!Occupied) return;
        Health -= power;
        if (hittedEff==null)
        {
            hittedEff = Instantiate(GameManager.instance.HittedEffPrefab).GetComponent<ParticleSystem>();
            hittedEff.transform.position = transform.position;
            Invoke(nameof(HideHitEff), 0.1f);
        }
    }
    void HideHitEff()
    {
        if (hittedEff == null) return;
        hittedEff.Stop();
        Destroy(hittedEff.gameObject, 0.5f);
        hittedEff=null;
    }
    public bool LevelUp(bool forced=false)
    {
        if(forced||GameManager.instance.SpendCoins(NextLevelCost))
        {
            level += 1;
            NextLevelCost *= Random.Range(1.8f, 2);
            if (level >= MaxLevel) NextLevelCost *= 1.8f;
            Enhancement enhancement = Enhancement.GetRandomEnhance(Mathf.Min(8, level));
            Enhancements.Add(enhancement);
            NowIds.Add(Enhancements.Count - 1);
            ApplyAll(NowIds.ToArray());
            StopUpingEff();
            upingEff = Instantiate(GameManager.instance.LevelUpEffPrefab).GetComponent<ParticleSystem>();
            upingEff.transform.position=transform.position;
            Invoke(nameof(StopUpingEff), 1f);
            return true;
        }
        return false;
    }
    void StopUpingEff()
    {
        if(upingEff != null)
        {
            upingEff.Stop();
            Destroy(upingEff.gameObject, 2f);
            upingEff= null;
        }
    }
    private void OnDestroy()
    {
        if(occpyingEff != null)
        {
            occpyingEff.Stop();
            Destroy(occpyingEff.gameObject, 2f);
            occpyingEff = null;
        }
        HideDiedEff();
        HideHitEff();
        StopUpingEff();
        PlayerLeave();
    }
    public void ApplyAll(int[] ids)
    {
        Values = (float[])OriginalValues.Clone();
        foreach(int id in ids)
        {
            Values = Enhancements[id].Apply(Values);
        }
        Values[1] = Mathf.Max(Values[1], 0);
        Values[2] = Mathf.Max(Values[2], 0);
        Values[3] = Mathf.Max(Values[3], 0);
        Values[4] = Mathf.Max(Values[4], 1);
        healRate = Values[4]/100f;
        NowIds = new List<int>(ids);
        SetLight();
        towerGun.UpdateData();
        if(rangeEff!=null)
            rangeEff.transform.localScale = Vector3.one * (towerGun.Scollider.radius * 100f);
        GameManager.instance.UpdateIncome();
    }

    public struct Enhancement
    {
        public readonly float[] ValuesEnhance;

        public readonly bool[] IsMultiply;

        public Enhancement(float coinsIncome, float attackPower, float attackSpeed, float attackRange, float healthMax)
        {
            ValuesEnhance = new float[] { coinsIncome, attackPower, attackSpeed, attackRange, healthMax };
            IsMultiply = new bool[] {false,false,false,false,false};
        }

        public Enhancement(float[] valuesEnhance, bool[] isMultiply)
        {
            ValuesEnhance = valuesEnhance;
            IsMultiply = isMultiply;
        }

        public float[] Apply(float[] Values) => Apply(Values, ValuesEnhance, IsMultiply);

        public static float[] StdAddMax = new float[] { 30, 40, 5f, 0.5f, 200 };
        public static float[] StdAddMin = new float[] { 5, 5, 2f, 0.2f, 70 };
        public static float[] StdMinuMax = new float[] { -10, -5, -2f, -0.2f, -20 };
        public static float[] StdMinuMin = new float[] { -20, -20, -4f, -0.8f, -80 };
        public static float[] StdMulMax = new float[] { 0.2f, 0.3f, 0.2f, 0.2f, 0.5f };
        public static float[] StdMulMin = new float[] { 0.1f, 0.1f, 0.1f, 0.1f, 0.2f };
        public static float[] StdDivMax = new float[] { -0.1f, -0.1f, -0.1f, -0.1f, -0.2f };
        public static float[] StdDivMin = new float[] { -0.2f, -0.2f, -0.2f, -0.2f, -0.3f };

        public static float GetStdValue(int i, int level, bool multiply, bool isbad)
        {
            if (multiply)
            {
                if (isbad)
                    return 1 + Random.Range(StdDivMin[i], StdDivMax[i]);
                return 1 + Random.Range(StdMulMin[i], StdMulMax[i]);
            }
            if (isbad)
                return Random.Range(StdMinuMin[i], StdMinuMax[i]);
            return Random.Range(StdAddMin[i], StdAddMax[i]);
        }

        public static Enhancement GetRandomEnhance(int level)
        {
            float[] Values = new float[5];
            bool[] IsMultiply = new bool[5];
            while(level > 0)
            {
                int i = Random.Range(0, 5);
                int k = Random.Range(0, 2);
                bool bad = Random.Range(0, 11-level) == 0;
                if (k == 0)
                {
                    if (IsMultiply[i])
                    {
                        IsMultiply[i] = false;
                        Values[i] *= GetStdValue(i, level, false,bad);
                    }
                    else
                        Values[i] += GetStdValue(i, level, false, bad);
                }
                else
                {
                    if (IsMultiply[i])
                    {
                        Values[i] += GetStdValue(i, level, true, bad) - 1;
                    }
                    else
                    {
                        if (Values[i] == 0)
                        {
                            Values[i] = GetStdValue(i, level, true, bad);
                            IsMultiply[i] = true;
                        }
                        else
                            Values[i] += GetStdValue(i, level, false, bad);
                    }
                }
                level -= 1;
            }
            return new Enhancement(Values, IsMultiply);
        }

        public string GetValueString(int i)
        {
            string s = i switch
            {
                0 => "coinsIncome",
                1 => "attackPower",
                2 => "attackSpeed",
                3 => "attackRange",
                4 => "healthMax",
                5 => "rage",
                6 => "attackAirRatio",
                _ => "???",
            };
            return s + ": " + (IsMultiply[i] ? "*" : (ValuesEnhance[i]>=0?"+":"")) + ValuesEnhance[i].ToString();
        }

        public override string ToString()
        {
            string s = "";
            for(int i=0;i<ValuesEnhance.Length;i++)
            {
                s += GetValueString(i);
                if (i != ValuesEnhance.Length - 1) s += "\n";
            }
            return s;
        }

        public static float[] Apply(float[] Ori, float[] enhance, bool[] ismulti)
        {
            for (int i = 0; i < enhance.Length; i++)
                if (ismulti[i]) Ori[i] *= enhance[i];
                else Ori[i] += enhance[i];
            return Ori;
        }
    }
}
