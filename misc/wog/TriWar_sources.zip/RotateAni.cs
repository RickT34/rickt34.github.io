using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotateAni : MonoBehaviour
{
    public float speed = 30f;
    public Vector3 Axis;
    // Update is called once per frame
    void Update()
    {
        if (GameManager.instance.Paused) return;
        transform.Rotate(Axis, speed * Time.deltaTime);
    }
}
