using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using static Cinemachine.DocumentationSortingAttribute;

public class Enemy : MonoBehaviour
{
    public bool Dead;
    public bool Air;
    public bool Range;
    public float Speed;
    public float Defence;
    Tower Target;
    Rigidbody rb;
    float attackCD;
    float attackCDori;
    bool attacking;
    public float Health
    {
        get => health;
        set
        {
            health = value;
            if (value <= 0)
            {
                Dead = true;
                Killed();
            }
        }
    }
    private float health;
    public float attackPower;
    public void Init(int rank, int level)
    {
        health = 100f* Mathf.Sqrt(level);
        Defence = 3 * Mathf.Sqrt(level);
        Speed =2 + Mathf.Sqrt(level);
        rb = GetComponent<Rigidbody>();
        Dead = false;
        attackPower = 5+3*level;
        Air = rank>1;
        Range = rank % 2 == 1;
        transform.GetChild(0).GetComponent<MeshFilter>().mesh = GameManager.instance.EnemyMeshes[rank%2];
        if(Air)
        {
            transform.GetChild(0).GetChild(0).gameObject.SetActive(true);
            //transform.GetChild(1).localScale *= (Mathf.Log(level + 1, 2));
        }
        transform.GetChild(0).localScale = new Vector3(0.5f, 0.5f, 0.5f)*0.3f * (Mathf.Log(level+1,2));
        GetComponent<SphereCollider>().radius = Range ? Mathf.Min(1.4f + Mathf.Log(level + 2, 2) * 0.2f, 4f) : 0.3f;
        if(!Range)
        {
            RotateAni ani = transform.GetChild(0).GetComponent<RotateAni>();
            ani.enabled = !Range;
            ani.speed = 180 + level * 10;
        }
        
        attackCDori = Mathf.Max(0.5f, 1.5f - level * 0.05f);
        attackCD = attackCDori;
        attacking = false; 
        UpdateTarget();
        gameObject.SetActive(true);
    }
    // Update is called once per frame
    void Update()
    {
        if(GameManager.instance.Paused) return;
        if(Target==null||!Target.Occupied)
        {
            UpdateTarget();
        }
        if (attacking)
        {
            if(attackCD>0)
                attackCD-=Time.deltaTime;
            else
            {
                attackCD = attackCDori;
                //Debug.Log(Target.ID);
                if (Range)
                {
                    Bullet bullet = Instantiate(GameManager.instance.BulletPrefab).GetComponent<Bullet>();
                    bullet.Init(transform.position, Target.transform, Target.ColRange, attackPower);
                }
                else
                {
                    Target.Hitted(attackPower);
                }
            }
            
        }
    }

    private void UpdateTarget()
    {
        Target = GameManager.instance.mapManager.GetNearestTower(transform.position, true);
        if(Target == null)rb.velocity = Vector3.zero;
        else
        {
            //Debug.Log(Target.ID);
            Vector3 to = Target.transform.position - transform.position;
            rb.velocity = GameManager.Constrains(to).normalized * Speed;
            if (Range)
                transform.eulerAngles = new Vector3(0, (Mathf.Atan2(transform.position.z - Target.transform.position.z, Target.transform.position.x - transform.position.x) * 180f) / Mathf.PI -135f, 0);
        }
        attacking = false;
    }
    ParticleSystem diedEff;
    void Killed()
    {
        diedEff = Instantiate(GameManager.instance.EnemyDiedPrefab).GetComponent<ParticleSystem>();
        diedEff.transform.position = transform.position;
        gameObject.SetActive(false);
        GameManager.instance.AddExp();
        GameManager.instance.Enemies.Remove(this);
        Destroy(gameObject, 1f);
    }
    private void OnDestroy()
    {
        if(diedEff!=null)
            Destroy(diedEff.gameObject);
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Tower")
        {
            Tower tower = other.gameObject.GetComponent<Tower>();
            if (tower.ID == Target.ID)
            {
                Stop();
                attacking = true;
            }
        }
    }
    private void OnTriggerExit(Collider other)
    {
        if (other.tag == "Tower")
        {
            Tower tower = other.gameObject.GetComponent<Tower>();
            if (tower.ID == Target.ID)
            {
                attacking = false;
            }
        }
    }
    void Stop()
    {
        //Debug.Log("Stop!");
        rb.velocity = Vector3.zero;
    }
    public void Hitted(float damage)
    {
        if(Dead) return;
        if (Air) damage = Mathf.Max(0, damage - Defence);
        Health -= damage;
    }
}
