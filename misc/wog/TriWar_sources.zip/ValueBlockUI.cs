using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class ValueBlockUI : MonoBehaviour
{
    public int ID;
    public int VID;
    ValuesUI valuesUI;
    Object textbase;
    TextMeshProUGUI[] Texts;
    public void Init(int ID, int VID, ValuesUI valuesUI, float[] values, bool[] ismulti, string name, bool buttons)
    {
        transform.GetChild(0).gameObject.SetActive(buttons);
        transform.GetChild(1).gameObject.SetActive(buttons);
        textbase = transform.GetChild(2).gameObject;
        this.VID = VID;
        this.ID = ID;
        this.valuesUI = valuesUI;
        textbase.GetComponent<TextMeshProUGUI>().text = name;
        transform.GetChild(0).GetComponent<Button>().onClick.AddListener(GoLeft);
        transform.GetChild(1).GetComponent<Button>().onClick.AddListener(GoRight);
        Texts=new TextMeshProUGUI[values.Length];
        for (int i = 0; i < values.Length; i++)
        {
            Object t1 = Instantiate(textbase, transform);
            t1.GetComponent<RectTransform>().anchoredPosition = new Vector3(0, -12f - 8f * (i+1));
            Texts[i] = t1.GetComponent<TextMeshProUGUI>();
        }
        SetText(values, ismulti);
        gameObject.SetActive(true);
    }
    public void SetText(float[] values, bool[] ismulti)
    {
        //Debug.Log(ismulti.Length);
        for (int i = 0; i < values.Length; i++)
        {
            string sh = ismulti[i] ? "*" : (values[i] >= 0 ? "+" : "");
            if ((ismulti[i] && values[i] < 1) || (!ismulti[i] && values[i] < 0)) sh = "<#520000>" + sh ;
            else if((ismulti[i] && values[i] > 1) || (!ismulti[i] && values[i] > 0)) sh = "<#022E00>" + sh ;
            else sh = "<#727272>" + sh;
            //Texts[i].font = GameManager.instance.NumberFont;
            Texts[i].text = string.Format(sh + "{0:f1}</color>", values[i]);
        }
    }
    public void SetText(string[] values)
    {
        for (int i = 0; i < values.Length; i++)
        {
            //Texts[i].font = GameManager.instance.WordFont;
            Texts[i].text = values[i];
        }
    }
    public void GoLeft()
    {
        valuesUI.Move(this, -1);
    }
    public void GoRight()
    {
        valuesUI.Move(this, 1);
    }
}
